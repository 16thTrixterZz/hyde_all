    import javax.swing.*;
    import javax.swing.border.*;
    import java.io.*;
    import java.awt.*;
    import java.awt.event.*;
    import java.awt.image.BufferedImage;
    import java.util.ArrayList;
    import java.util.HashMap;
    import java.util.List;
    import java.util.Map;
    import java.util.Random;
    import javax.imageio.ImageIO;
    import javax.imageio.ImageReader;
    import javax.imageio.stream.ImageInputStream;
    import javax.sound.sampled.*;

    import java.util.Iterator;
    import java.util.Date;
    import java.text.SimpleDateFormat;

    public class DinosaurGameV3 extends JFrame implements ActionListener, KeyListener {

        private boolean gameFinished = false;
        private BufferedImage endingSprite;
        private boolean isMeteorPhase = false;
        private ArrayList<Meteor> meteors = new ArrayList<>();

        private boolean canDoubleJump = false;
        private boolean hasDoubleJumped = false;
        private final int DOUBLE_JUMP_STRENGTH = 18;

        private int screenShakeOffset = 0;
        private Map<String, BufferedImage> imageCache = new HashMap<>();
        private float volume = 0.7f;
        private boolean isPaused = false;

        private CardLayout cardLayout;
        private JPanel mainContainer;
        private static final int WIDTH = 1400;
        private static final int HEIGHT = 800;
        private int getGroundLevel() {
            return getHeight() - 90; 
        }

        private static final int GRAVITY = 1;
        private static final int JUMP_STRENGTH = 20;
        private Timer gameTimer;
        private int dinosaurY;
        private int dinosaurVelocity;
        private boolean isJumping;
        private boolean gameRunning;
        private int score;
        private int highScore;
        private int gameSpeed;
        private ArrayList<Obstacle> obstacles;

        private Random random;
        private ArrayList<Cloud> clouds;
        private ArrayList<TerrainSegment> terrainSegments;
        private List<BufferedImage> dinoRunFrames;
        private List<BufferedImage> dinoDuckFrames;
        private BufferedImage dinoJump;
        private BufferedImage titleSprite;
        private BufferedImage rockSprite, treeSprite, pterodactylSprite;
        private List<BufferedImage> allCutsceneSprites;
        private List<String> cutsceneTypes;

        private int animationFrame = 0;
        private int currentRunFrame = 0;
        private int currentDuckFrame = 0;
        private int animationCounter = 0;

        private final int ANIMATION_DELAY = 5;
        private boolean isDucking = false;
        private boolean isNightMode = false;
        private int spawnChance = 3; 
        private int dayNightCounter = 0;
        private int obstacleSpawnCounter = 0;
        private final int MIN_OBSTACLE_DISTANCE = 100; 

        private JLabel scoreLabel;
        private JLabel highScoreLabel;
        private JButton startButton;
        private JPanel finishedPanel;

        private Clip jumpSound;
        private Clip runSound;
        private Clip crashSound;
        private boolean soundsLoaded = false;

        private PlayerProfile currentPlayer;
        private Map<Integer, PlayerProfile> savedGames;

        private static final String SAVE_FILE = "dino_save_data.dat";
        private static final int MAX_SAVE_SLOTS = 5;
        
        private final Color PRIMARY_COLOR = new Color(46, 139, 87);
        private final Color SECONDARY_COLOR = new Color(34, 113, 70);
        private final Color ACCENT_COLOR = new Color(240, 180, 50);
        private final Color DARK_BG = new Color(30, 30, 40);
        private final Color LIGHT_TEXT = new Color(240, 240, 240);

        private static final int BUTTON_WIDTH = 200;
        private static final int BUTTON_HEIGHT = 30;
        private static final int SMALL_BUTTON_WIDTH = 120;
        private static final int SMALL_BUTTON_HEIGHT = 24;

        private int currentCutsceneIndex = 0;
        private Timer cutsceneTimer;
        private static final int CUTSCENE_DELAY = 4000;
        private JLabel cutsceneImageLabel;
        private JLabel progressLabel;
        private JTextArea storyText;

        private JButton nextButton;
        private JButton startButtonCutscene;

        public DinosaurGameV3() {
            setTitle("Prehistoric Rush");
            setSize(WIDTH, HEIGHT);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setLocationRelativeTo(null);
            setResizable(true);
            setMinimumSize(new Dimension(400, 200));
            initializeGameComponents();
            setupMainUI();

            initializeGame();
            setVisible(true);
        }

        private void initializeGameComponents() {
            savedGames = new HashMap<>();
            loadSavedGames();

            loadAnimatedGIFs();
            loadCutsceneSprites();
            loadSounds();
            
            random = new Random();
            obstacles = new ArrayList<>();
            clouds = new ArrayList<>();
            terrainSegments = new ArrayList<>();
            
            cutsceneTimer = new Timer(CUTSCENE_DELAY, e -> advanceCutscene());
        }

        private void setupMainUI() {
            cardLayout = new CardLayout();
            mainContainer = new JPanel(cardLayout);
            mainContainer.setBackground(DARK_BG);

            JPanel titleScreenPanel = createTitleScreenPanel();
            JPanel gamePanelContainer = createGamePanelContainer();
            JPanel startGamePanel = createStartGamePanel();
            JPanel leaderboardsPanel = createLeaderboardsPanel();
            
            mainContainer.add(titleScreenPanel, "TITLE");
            mainContainer.add(gamePanelContainer, "GAME");
            mainContainer.add(startGamePanel, "START_GAME");
            mainContainer.add(leaderboardsPanel, "LEADERBOARDS");
        
            setContentPane(mainContainer);
            
            addKeyListener(this);
            setFocusable(true);
            gameTimer = new Timer(20, this);

            cardLayout.show(mainContainer, "TITLE");

            addComponentListener(new ComponentAdapter() {
                @Override
                public void componentResized(ComponentEvent e) {
                    handleWindowResize();
                    if (cutsceneImageLabel != null && cutsceneImageLabel.getIcon() != null) {
                        updateCutsceneImageSize();
                    }
                }
            });
        }

        

        class Meteor {
            int x, y, speed, size;
            Color color;
            int trailLength;
            
            Meteor() {
                this.size = 30 + random.nextInt(40);
                this.x = random.nextInt(getWidth());
                this.y = -size; 
                this.speed = 8 + random.nextInt(8);
                this.color = new Color(255, 100, 0);
                this.trailLength = 10 + random.nextInt(20);
            }
            
            void move() {
                y += speed;
                x -= speed / 2; 
            }
            
            boolean isOffScreen() {
                return y > getHeight() || x + size < 0;
            }
            
            void draw(Graphics2D g2d) {
                for (int i = 0; i < trailLength; i++) {
                    int trailAlpha = 150 - (i * 10);
                    int trailSize = size - (i * 2);
                    if (trailAlpha > 0 && trailSize > 0) {
                        g2d.setColor(new Color(255, 165, 0, trailAlpha));
                        g2d.fillOval(x - i * 2, y - i * 4, trailSize, trailSize);
                    }
                }
                
                g2d.setColor(color);
                g2d.fillOval(x, y, size, size);
                
                g2d.setColor(new Color(255, 200, 100, 100));
                g2d.fillOval(x - 5, y - 5, size + 10, size + 10);
            }
        }

        private void handleWindowResize() {
            if (!isJumping) {
                dinosaurY = getGroundLevel();
            }
            for (Obstacle obstacle : obstacles) {
                if (obstacle.type == 0 || obstacle.type == 1) {
                    obstacle.y = getGroundLevel() - obstacle.height;
                }
            }
            generateTerrain();
            repaint();
        }

        private JPanel createGamePanelContainer() {
            JPanel gamePanelContainer = new JPanel(new BorderLayout());
            
            JPanel gamePanel = new JPanel() {
                @Override
                protected void paintComponent(Graphics g) {
                    super.paintComponent(g);
                    drawGame(g);
                }
            };
            gamePanel.setBackground(Color.WHITE);
            gamePanel.setPreferredSize(new Dimension(WIDTH, HEIGHT));

            JPanel uiPanel = createUIPanel();

            gamePanelContainer.add(gamePanel, BorderLayout.CENTER);
            gamePanelContainer.add(uiPanel, BorderLayout.NORTH);
            
            return gamePanelContainer;
        }

        private JPanel createUIPanel() {
            JPanel uiPanel = new JPanel(new BorderLayout());
            uiPanel.setBackground(DARK_BG);
            uiPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
            
            scoreLabel = new JLabel("Score: 0");
            highScoreLabel = new JLabel("High Score: 0");
            
            scoreLabel.setFont(new Font("Arial", Font.BOLD, 16));
            highScoreLabel.setFont(new Font("Arial", Font.BOLD, 16));
            scoreLabel.setForeground(LIGHT_TEXT);
            highScoreLabel.setForeground(ACCENT_COLOR);

            startButton = createActionButton("Start Game");
            startButton.addActionListener(e -> startGame());

            JPanel scorePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 0));
            scorePanel.setBackground(DARK_BG);
            scorePanel.add(scoreLabel);
            scorePanel.add(highScoreLabel);

            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
            buttonPanel.setBackground(DARK_BG);
            buttonPanel.add(startButton);

            uiPanel.add(scorePanel, BorderLayout.WEST);
            uiPanel.add(buttonPanel, BorderLayout.EAST);
            
            return uiPanel;
        }

        private void loadCutsceneSprites() {
            allCutsceneSprites = new ArrayList<>();
            cutsceneTypes = new ArrayList<>();
            
            try {
                for (int i = 1; i <= 4; i++) {
                    BufferedImage cgSprite = loadImage("Assets/Sprites/UI/cg" + i + ".PNG");
                    if (cgSprite != null) {
                        allCutsceneSprites.add(cgSprite);
                        cutsceneTypes.add("CG");
                    } else {
                        System.err.println("Failed to load cutscene sprite: cg" + i + ".PNG");
                        allCutsceneSprites.add(createFallbackImage("CG " + i, Color.BLUE));
                        cutsceneTypes.add("CG");
                    }
                    
                    BufferedImage cgmSprite = loadImage("Assets/Sprites/UI/cgm" + i + ".png");
                    if (cgmSprite != null) {
                        allCutsceneSprites.add(cgmSprite);
                        cutsceneTypes.add("CGM");
                    } else {
                        System.err.println("Failed to load cutscene monster sprite: cgm" + i + ".png");
                        allCutsceneSprites.add(createFallbackImage("CGM " + i, Color.RED));
                        cutsceneTypes.add("CGM");
                    }
                }
                
                if (allCutsceneSprites.isEmpty()) {
                    createCompleteFallbackCutsceneSprites();
                }
                
            } catch (Exception e) {
                System.err.println("Error loading cutscene sprites: " + e.getMessage());
                createCompleteFallbackCutsceneSprites();
            }
        }
        

        private BufferedImage createFallbackImage(String text, Color color) {
            BufferedImage img = new BufferedImage(800, 600, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2d = img.createGraphics();
            g2d.setColor(color);
            g2d.fillRect(0, 0, 800, 600);
            g2d.setColor(Color.WHITE);
            g2d.setFont(new Font("Arial", Font.BOLD, 32));
            FontMetrics fm = g2d.getFontMetrics();
            int textWidth = fm.stringWidth(text);
            g2d.drawString(text, (800 - textWidth) / 2, 300);
            g2d.dispose();
            return img;
        }

        private void createCompleteFallbackCutsceneSprites() {
            allCutsceneSprites = new ArrayList<>();
            cutsceneTypes = new ArrayList<>();
            
            Color[] colors = {Color.BLUE, Color.RED, Color.GREEN, Color.ORANGE, 
                            Color.CYAN, Color.MAGENTA, Color.YELLOW, Color.PINK};
            String[] types = {"CG", "CGM", "CG", "CGM", "CG", "CGM", "CG", "CGM"};
            
            for (int i = 0; i < 8; i++) {
                BufferedImage img = new BufferedImage(800, 600, BufferedImage.TYPE_INT_ARGB);
                Graphics2D g2d = img.createGraphics();
                g2d.setColor(colors[i]);
                g2d.fillRect(0, 0, 800, 600);
                g2d.setColor(Color.WHITE);
                g2d.setFont(new Font("Arial", Font.BOLD, 32));
                String text = types[i] + " " + ((i / 2) + 1);
                FontMetrics fm = g2d.getFontMetrics();
                int textWidth = fm.stringWidth(text);
                g2d.drawString(text, (800 - textWidth) / 2, 300);
                g2d.dispose();
                allCutsceneSprites.add(img);
                cutsceneTypes.add(types[i]);
            }
        }

        private void updateCutsceneImageSize() {
            if (cutsceneImageLabel != null && currentCutsceneIndex < allCutsceneSprites.size()) {
                BufferedImage original = allCutsceneSprites.get(currentCutsceneIndex);
                Dimension newSize = calculateOptimalImageSize();
                BufferedImage scaled = scaleImage(original, newSize.width, newSize.height);
                cutsceneImageLabel.setIcon(new ImageIcon(scaled));
            }
        }

        private Dimension calculateOptimalImageSize() {
            int maxWidth = getWidth() - 100; 
            int maxHeight = getHeight() - 200; 

            if (currentCutsceneIndex < allCutsceneSprites.size()) {
                BufferedImage img = allCutsceneSprites.get(currentCutsceneIndex);
                double aspectRatio = (double) img.getWidth() / img.getHeight();
                
                int width = maxWidth;
                int height = (int) (width / aspectRatio);
                
                if (height > maxHeight) {
                    height = maxHeight;
                    width = (int) (height * aspectRatio);
                }
                
                return new Dimension(width, height);
            }
            
            return new Dimension(600, 400);
        }

        private BufferedImage scaleImage(BufferedImage original, int width, int height) {
            BufferedImage scaled = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2d = scaled.createGraphics();
            g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2d.drawImage(original, 0, 0, width, height, null);
            g2d.dispose();
            return scaled;
        }

        private void showCutscene() {
            currentCutsceneIndex = 0;
            
            JPanel cutscenePanel = new JPanel(new BorderLayout());
            cutscenePanel.setBackground(DARK_BG);
            cutscenePanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
            
            JPanel contentPanel = new JPanel(new BorderLayout());
            contentPanel.setBackground(DARK_BG);
            
            JPanel progressPanel = new JPanel(new FlowLayout());
            progressPanel.setBackground(DARK_BG);
            progressLabel = new JLabel("Scene 1 of " + allCutsceneSprites.size());
            progressLabel.setFont(new Font("Arial", Font.BOLD, 16));
            progressLabel.setForeground(LIGHT_TEXT);
            progressPanel.add(progressLabel);
            
            JPanel scenePanel = new JPanel(new BorderLayout());
            scenePanel.setBackground(DARK_BG);
            scenePanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
            
            cutsceneImageLabel = new JLabel();
            cutsceneImageLabel.setHorizontalAlignment(JLabel.CENTER);
            cutsceneImageLabel.setVerticalAlignment(JLabel.CENTER);
            
            JScrollPane imageScrollPane = new JScrollPane(cutsceneImageLabel);
            imageScrollPane.setBorder(BorderFactory.createEmptyBorder());
            imageScrollPane.getViewport().setBackground(DARK_BG);
            imageScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
            imageScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
            
            scenePanel.add(imageScrollPane, BorderLayout.CENTER);
            
            JPanel textPanel = new JPanel(new BorderLayout());
            textPanel.setBackground(DARK_BG);
            textPanel.setBorder(BorderFactory.createEmptyBorder(10, 40, 10, 40));
            
            storyText = new JTextArea();
            storyText.setFont(new Font("Arial", Font.PLAIN, 16));
            storyText.setForeground(LIGHT_TEXT);
            storyText.setBackground(DARK_BG);
            storyText.setEditable(false);
            storyText.setLineWrap(true);
            storyText.setWrapStyleWord(true);
            storyText.setText(getCutsceneText(0));
            
            textPanel.add(storyText, BorderLayout.CENTER);
            
            JPanel buttonPanel = new JPanel();
            buttonPanel.setBackground(DARK_BG);
            buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));
            
            JButton skipButton = createActionButton("SKIP CUTSCENE");
            nextButton = createActionButton("NEXT SCENE");
            startButtonCutscene = createMinecraftStyleButton("BEGIN ADVENTURE", PRIMARY_COLOR);
            
            skipButton.addActionListener(e -> {
                cutsceneTimer.stop();
                startGameFromCutscene();
            });
            
            nextButton.addActionListener(e -> advanceCutscene());
            
            startButtonCutscene.addActionListener(e -> {
                cutsceneTimer.stop();
                startGameFromCutscene();
            });
            
            startButtonCutscene.setVisible(false);
            
            buttonPanel.add(skipButton);
            buttonPanel.add(Box.createHorizontalStrut(10));
            buttonPanel.add(nextButton);
            buttonPanel.add(Box.createHorizontalStrut(10));
            buttonPanel.add(startButtonCutscene);
            
            contentPanel.add(progressPanel, BorderLayout.NORTH);
            contentPanel.add(scenePanel, BorderLayout.CENTER);
            contentPanel.add(textPanel, BorderLayout.SOUTH);
            
            cutscenePanel.add(contentPanel, BorderLayout.CENTER);
            cutscenePanel.add(buttonPanel, BorderLayout.SOUTH);
            
            updateCutsceneDisplay();
            
            mainContainer.add(cutscenePanel, "CUTSCENE");
            cardLayout.show(mainContainer, "CUTSCENE");
            
            cutsceneTimer.start();
        }
        private void updateCutsceneDisplay() {
            if (currentCutsceneIndex < allCutsceneSprites.size()) {
                BufferedImage original = allCutsceneSprites.get(currentCutsceneIndex);
                Dimension optimalSize = calculateOptimalImageSize();
                BufferedImage scaled = scaleImage(original, optimalSize.width, optimalSize.height);
                cutsceneImageLabel.setIcon(new ImageIcon(scaled));
                
                progressLabel.setText("Scene " + (currentCutsceneIndex + 1) + " of " + allCutsceneSprites.size());
                storyText.setText(getCutsceneText(currentCutsceneIndex));
                
                if (currentCutsceneIndex >= allCutsceneSprites.size() - 1) {
                    nextButton.setVisible(false);
                    startButtonCutscene.setVisible(true);
                } else {
                    nextButton.setVisible(true);
                    startButtonCutscene.setVisible(false);
                }
            }
        }

        private void advanceCutscene() {
            currentCutsceneIndex++;
            if (currentCutsceneIndex >= allCutsceneSprites.size()) {
                currentCutsceneIndex = allCutsceneSprites.size() - 1;
                cutsceneTimer.stop();
            }
            
            updateCutsceneDisplay();
            
            if (currentCutsceneIndex < allCutsceneSprites.size() - 1) {
                cutsceneTimer.restart();
            }
        }

        private String getCutsceneText(int sceneIndex) {
            String[] sceneTexts = {
                "In the dawn of time, when ancient creatures roamed the earth...",
                "A mysterious presence emerges from the primordial mists...",
                "The journey begins through lush prehistoric landscapes...",
                "Danger lurks in the shadows of the ancient world...",
                "Our hero faces new challenges under the scorching sun...",
                "Strange creatures watch from the depths of the jungle...",
                "The path grows treacherous as night begins to fall...",
                "The final confrontation approaches in this lost world..."
            };
            
            String type = sceneIndex < cutsceneTypes.size() ? cutsceneTypes.get(sceneIndex) : "Scene";
            String baseText = sceneIndex < sceneTexts.length ? sceneTexts[sceneIndex] : "The adventure continues...";
            
            return String.format("%s %d: %s", type, (sceneIndex / 2) + 1, baseText);
        }

        private void startGameFromCutscene() {
            for (Component comp : mainContainer.getComponents()) {
                if (comp instanceof JPanel) {
                    JPanel panel = (JPanel) comp;
                    if (panel.getComponentCount() > 0) {
                        Component firstChild = panel.getComponent(0);
                        if (firstChild instanceof JPanel) {
                            JPanel innerPanel = (JPanel) firstChild;
                            if (innerPanel.getComponentCount() > 0 && 
                                innerPanel.getComponent(0) instanceof JLabel) {
                                JLabel testLabel = (JLabel) innerPanel.getComponent(0);
                                if (testLabel.getText() != null && testLabel.getText().startsWith("Scene")) {
                                    mainContainer.remove(panel);
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            
            cardLayout.show(mainContainer, "GAME");
            startGame();
        }
        class PlayerProfile implements Serializable {
            private static final long serialVersionUID = 1L;
            String playerName;
            int highScore;
            int currentScore;
            boolean hasSaveGame;
            Date lastPlayed;
            Date dateCreated;
            
            PlayerProfile(String name) {
                this.playerName = name;
                this.highScore = 0;
                this.currentScore = 0;
                this.hasSaveGame = false;
                this.lastPlayed = new Date();
                this.dateCreated = new Date();
            }
            
            void updateScore(int newScore) {
                this.currentScore = newScore;
                if (newScore > highScore) {
                    highScore = newScore;
                }
                this.lastPlayed = new Date();
                this.hasSaveGame = true;
            }
            
            void resetGame() {
                this.currentScore = 0;
                this.hasSaveGame = false;
            }
            
            @Override
            public String toString() {
                SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy");
                return String.format("%s - High Score: %d - Last Played: %s", 
                    playerName, highScore, sdf.format(lastPlayed));
            }
        }

        class Cloud {
            int x, y, speed, size;
            
            Cloud(int x, int y, int speed, int size) {
                this.x = x;
                this.y = y;
                this.speed = speed;
                this.size = size;
            }
            
            void move() {
                x -= speed;
                if (x + size < 0) {
                    x = getWidth();
                    y = 30 + random.nextInt(100);
                }
            }
        }

        class TerrainSegment {
            int x, height, width;
            Color color;
            boolean hasGrass;
            
            TerrainSegment(int x, int height, int width, Color color, boolean hasGrass) {
                this.x = x;
                this.height = height;
                this.width = width;
                this.color = color;
                this.hasGrass = hasGrass;
            }
            
            void move(int speed) {
                x -= speed;
            }
            
            void draw(Graphics2D g2d, int groundLevel) {
                g2d.setColor(color);
                g2d.fillRect(x, groundLevel - height, width, height);
                
                if (hasGrass) {
                    g2d.setColor(isNightMode ? new Color(40, 100, 40) : new Color(34, 139, 34));
                    for (int i = 0; i < width; i += 4) {
                        int grassHeight = 3 + random.nextInt(5);
                        g2d.drawLine(x + i, groundLevel - height, x + i, groundLevel - height - grassHeight);
                    }
                }
            }
        }

        class Obstacle {
            int x, y, width, height, type;
            int moveDirection;
            boolean isMoving;
            int animationFrame;
            
            Obstacle(int type) {
                this.type = type;
                this.animationFrame = 0;
                int groundLevel = getGroundLevel();
                
                switch(type) {
                    case 0: 
                        width = 85;
                        height = 120;
                        y = groundLevel - height;
                        isMoving = false;
                        break;
                    case 1: 
                        width = 100;
                        height = 150;
                        y = groundLevel - height;
                        isMoving = false;
                        break;
                    case 2: 
                        width = 100;
                        height = 50;
                        y = groundLevel - 60 - random.nextInt(40);
                        isMoving = true;
                        moveDirection = random.nextBoolean() ? 1 : -1;
                        break;
                }
                x = getWidth();
            }
            
            void move(int speed) {
                x -= speed;
                
                if (isMoving) {
                    y += moveDirection * 2;
                    if (y <= getGroundLevel() - 200 || y >= getGroundLevel() - 60) {
                        moveDirection *= -1;
                    }
                }
                
                if (type == 2) {
                    animationFrame = (animationFrame + 1) % 20;
                }
            }
            
            BufferedImage getSprite() {
                switch(type) {
                    case 0: return rockSprite;
                    case 1: return treeSprite;
                    case 2: return pterodactylSprite;
                    default: return null;
                }
            }
            
            Rectangle getBounds() {
                return new Rectangle(x, y, width, height);
            }
        }

        private BufferedImage getScaledCutsceneImage(int index, Dimension size) {
            String cacheKey = index + "_" + size.width + "x" + size.height;
            if (!imageCache.containsKey(cacheKey)) {
                BufferedImage scaled = scaleImage(allCutsceneSprites.get(index), size.width, size.height);
                imageCache.put(cacheKey, scaled);
            }
            return imageCache.get(cacheKey);
        }

        private JPanel createTitleScreenPanel() {
            JPanel panel = new JPanel(new BorderLayout());
            panel.setBackground(DARK_BG);
            panel.setBorder(BorderFactory.createEmptyBorder(40, 20, 40, 20));

            JPanel titlePanel = new JPanel(new BorderLayout());
            titlePanel.setBackground(DARK_BG);
            titlePanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 40, 0));

            if (titleSprite != null) {
                ImageIcon titleIcon = new ImageIcon(titleSprite);
                JLabel titleImageLabel = new JLabel(titleIcon);
                titleImageLabel.setHorizontalAlignment(JLabel.CENTER);
                titlePanel.add(titleImageLabel, BorderLayout.CENTER);
            } else {
                JLabel titleLabel = new JLabel("PREHISTORIC RUSH", JLabel.CENTER);
                titleLabel.setFont(new Font("Arial", Font.BOLD, 42));
                titleLabel.setForeground(ACCENT_COLOR);
                titleLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
                titlePanel.add(titleLabel, BorderLayout.CENTER);
            }

            JPanel buttonPanel = new JPanel();
            buttonPanel.setBackground(DARK_BG);
            buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
            buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));

            JButton startGameButton = createMinecraftStyleButton("START GAME", PRIMARY_COLOR);
            JButton leaderboardsButton = createMinecraftStyleButton("LEADERBOARDS", new Color(70, 130, 180));
            JButton quitButton = createMinecraftStyleButton("QUIT GAME", new Color(180, 70, 70));

            startGameButton.addActionListener(e -> showStartGameScreen());
            leaderboardsButton.addActionListener(e -> showLeaderboards());
            quitButton.addActionListener(e -> {
                saveGameData();
                System.exit(0);
            });

            startGameButton.setAlignmentX(Component.CENTER_ALIGNMENT);
            leaderboardsButton.setAlignmentX(Component.CENTER_ALIGNMENT);
            quitButton.setAlignmentX(Component.CENTER_ALIGNMENT);

            buttonPanel.add(Box.createVerticalStrut(10));
            buttonPanel.add(startGameButton);
            buttonPanel.add(Box.createVerticalStrut(8));
            buttonPanel.add(leaderboardsButton);
            buttonPanel.add(Box.createVerticalStrut(8));
            buttonPanel.add(quitButton);
            buttonPanel.add(Box.createVerticalStrut(10));

            panel.add(titlePanel, BorderLayout.NORTH);
            panel.add(buttonPanel, BorderLayout.CENTER);
            
            return panel;
        }

        
        private JButton createMinecraftStyleButton(String text, Color bgColor) {
            JButton button = new JButton(text) {
                @Override
                protected void paintComponent(Graphics g) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    
                    if (getModel().isPressed()) {
                        g2.setColor(darken(bgColor, 0.3f));
                    } else if (getModel().isRollover()) {
                        g2.setColor(lighten(bgColor, 0.1f));
                    } else {
                        g2.setColor(bgColor);
                    }
                    
                    g2.fillRect(0, 0, getWidth(), getHeight());
                    g2.setColor(darken(bgColor, 0.4f));
                    g2.drawRect(0, 0, getWidth()-1, getHeight()-1);
                    g2.setColor(lighten(bgColor, 0.2f));
                    g2.drawLine(0, 0, getWidth()-1, 0);
                    g2.drawLine(0, 0, 0, getHeight()-1);
                    g2.setColor(LIGHT_TEXT);
                    g2.setFont(getFont());
                    FontMetrics fm = g2.getFontMetrics();
                    int x = (getWidth() - fm.stringWidth(getText())) / 2;
                    int y = (getHeight() - fm.getHeight()) / 2 + fm.getAscent();
                    g2.drawString(getText(), x, y);
                    g2.dispose();
                }
            };
            
            button.setPreferredSize(new Dimension(BUTTON_WIDTH, BUTTON_HEIGHT));
            button.setMinimumSize(new Dimension(BUTTON_WIDTH, BUTTON_HEIGHT));
            button.setMaximumSize(new Dimension(BUTTON_WIDTH, BUTTON_HEIGHT));
            button.setFont(new Font("Arial", Font.BOLD, 14));
            button.setForeground(LIGHT_TEXT);
            button.setFocusPainted(false);
            button.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));
            button.setContentAreaFilled(false);
            button.setCursor(new Cursor(Cursor.HAND_CURSOR));
            
            return button;
        }

        private JButton createActionButton(String text) {
            JButton button = new JButton(text);
            button.setPreferredSize(new Dimension(SMALL_BUTTON_WIDTH, SMALL_BUTTON_HEIGHT));
            button.setFont(new Font("Arial", Font.BOLD, 11));
            button.setBackground(new Color(80, 80, 100));
            button.setForeground(LIGHT_TEXT);
            button.setFocusPainted(false);
            button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(120, 120, 140), 1),
                BorderFactory.createEmptyBorder(2, 8, 2, 8)
            ));
            button.setCursor(new Cursor(Cursor.HAND_CURSOR));
            
            button.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    button.setBackground(new Color(100, 100, 130));
                }
                
                @Override
                public void mouseExited(MouseEvent e) {
                    button.setBackground(new Color(80, 80, 100));
                }
            });
            
            return button;
        }

        private JPanel createSettingsPanel() {
            JPanel panel = new JPanel(new BorderLayout());
            panel.setBackground(DARK_BG);
            panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

            JLabel titleLabel = new JLabel("SETTINGS", JLabel.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
            titleLabel.setForeground(ACCENT_COLOR);
            
            JSlider volumeSlider = new JSlider(0, 100, (int)(volume * 100));
            volumeSlider.addChangeListener(e -> {
                volume = volumeSlider.getValue() / 100f;
            });
            
            JCheckBox muteCheckbox = new JCheckBox("Mute Sounds");
            muteCheckbox.addActionListener(e -> {
                soundsLoaded = !muteCheckbox.isSelected();
            });

            return panel;
        }

        private Color darken(Color color, float factor) {
            return new Color(
                Math.max((int)(color.getRed() * factor), 0),
                Math.max((int)(color.getGreen() * factor), 0),
                Math.max((int)(color.getBlue() * factor), 0)
            );
        }

        private Color lighten(Color color, float factor) {
            return new Color(
                Math.min((int)(color.getRed() * (1 + factor)), 255),
                Math.min((int)(color.getGreen() * (1 + factor)), 255),
                Math.min((int)(color.getBlue() * (1 + factor)), 255)
            );
        }

        private JPanel createStartGamePanel() {
            JPanel panel = new JPanel(new BorderLayout());
            panel.setBackground(DARK_BG);
            panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

            JLabel titleLabel = new JLabel("SELECT SAVE SLOT", JLabel.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
            titleLabel.setForeground(ACCENT_COLOR);
            titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 30, 0));
            panel.add(titleLabel, BorderLayout.NORTH);

            JPanel slotsPanel = new JPanel(new GridLayout(MAX_SAVE_SLOTS, 1, 10, 10));
            slotsPanel.setBackground(DARK_BG);
            slotsPanel.setBorder(BorderFactory.createEmptyBorder(10, 40, 10, 40));

            for (int i = 1; i <= MAX_SAVE_SLOTS; i++) {
                JPanel slotPanel = createSaveSlotPanel(i);
                slotsPanel.add(slotPanel);
            }

            JScrollPane scrollPane = new JScrollPane(slotsPanel);
            scrollPane.setBorder(BorderFactory.createEmptyBorder());
            scrollPane.getViewport().setBackground(DARK_BG);
            panel.add(scrollPane, BorderLayout.CENTER);

            JPanel backPanel = new JPanel();
            backPanel.setBackground(DARK_BG);
            backPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 0, 0));
            JButton backButton = createActionButton("BACK TO TITLE");
            backButton.addActionListener(e -> cardLayout.show(mainContainer, "TITLE"));
            backPanel.add(backButton);
            panel.add(backPanel, BorderLayout.SOUTH);

            return panel;
        }

        private JPanel createSaveSlotPanel(int slotNumber) {
            JPanel panel = new JPanel(new BorderLayout());
            panel.setBackground(new Color(50, 50, 65));
            panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(80, 80, 100), 1),
                BorderFactory.createEmptyBorder(8, 12, 8, 12)
            ));
            panel.setPreferredSize(new Dimension(400, 50));

            PlayerProfile profile = savedGames.get(slotNumber);
            String slotName = getSlotName(slotNumber);
            String slotText;
            if (profile != null) {
                slotText = String.format("%s: %s (High Score: %d)", 
                    slotName, profile.playerName, profile.highScore);
            } else {
                slotText = String.format("%s: EMPTY", slotName);
            }

            JLabel slotLabel = new JLabel(slotText);
            slotLabel.setFont(new Font("Arial", Font.BOLD, 12));
            slotLabel.setForeground(LIGHT_TEXT);

            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 4, 0));
            buttonPanel.setBackground(new Color(50, 50, 65));
            
            JButton selectButton = createActionButton("SELECT");
            JButton continueButton = createActionButton("CONTINUE");
            JButton deleteButton = createActionButton("DELETE");

            selectButton.addActionListener(e -> handleSlotSelection(slotNumber, profile));
            continueButton.addActionListener(e -> handleSlotContinue(slotNumber, profile));
            deleteButton.addActionListener(e -> deleteSaveSlot(slotNumber));

            if (profile != null) {
                selectButton.setEnabled(false);
                selectButton.setBackground(new Color(60, 60, 70));
                continueButton.setEnabled(profile.hasSaveGame);
                if (!profile.hasSaveGame) {
                    continueButton.setBackground(new Color(60, 60, 70));
                }
            } else {
                continueButton.setEnabled(false);
                continueButton.setBackground(new Color(60, 60, 70));
                deleteButton.setEnabled(false);
                deleteButton.setBackground(new Color(60, 60, 70));
            }

            buttonPanel.add(selectButton);
            buttonPanel.add(continueButton);
            buttonPanel.add(deleteButton);

            panel.add(slotLabel, BorderLayout.CENTER);
            panel.add(buttonPanel, BorderLayout.EAST);

            return panel;
        }

        private String getSlotName(int slotNumber) {
            switch(slotNumber) {
                case 1: return "First Occurence";
                case 2: return "Second Occurence";
                case 3: return "Third Occurence";
                case 4: return "Fourth Occurence";
                case 5: return "Fifth Occurence";
                default: return "Slot " + slotNumber;
            }
        }

        private void handleSlotSelection(int slotNumber, PlayerProfile existingProfile) {
            if (existingProfile == null) {
                String playerName = JOptionPane.showInputDialog(this, 
                    "Enter your name:", "New Player", JOptionPane.QUESTION_MESSAGE);
                
                if (playerName != null && !playerName.trim().isEmpty()) {
                    PlayerProfile newProfile = new PlayerProfile(playerName.trim());
                    savedGames.put(slotNumber, newProfile);
                    currentPlayer = newProfile;
                    saveGameData();
                    refreshStartGamePanel();
                    showCutscene();
                }
            }
        }

        private void handleSlotContinue(int slotNumber, PlayerProfile profile) {
            if (profile != null && profile.hasSaveGame) {
                currentPlayer = profile;
                cardLayout.show(mainContainer, "GAME");
                startGame();
            }
        }

        private void deleteSaveSlot(int slotNumber) {
            PlayerProfile profile = savedGames.get(slotNumber);
            if (profile == null) return;
            
            int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete " + profile.playerName + "'s save data?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION);
            
            if (confirm == JOptionPane.YES_OPTION) {
                savedGames.remove(slotNumber);
                saveGameData();
                refreshStartGamePanel();
            }
        }

        private void refreshStartGamePanel() {
            mainContainer.remove(mainContainer.getComponent(2));
            mainContainer.add(createStartGamePanel(), "START_GAME");
            cardLayout.show(mainContainer, "START_GAME");
        }

        private void refreshLeaderboardsPanel() {
            mainContainer.remove(mainContainer.getComponent(3));
            mainContainer.add(createLeaderboardsPanel(), "LEADERBOARDS");
        }

        private JPanel createLeaderboardsPanel() {
            JPanel panel = new JPanel(new BorderLayout());
            panel.setBackground(DARK_BG);
            panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

            JLabel titleLabel = new JLabel("LEADERBOARDS", JLabel.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
            titleLabel.setForeground(ACCENT_COLOR);
            titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 30, 0));
            panel.add(titleLabel, BorderLayout.NORTH);

            JTextArea leaderboardText = new JTextArea();
            leaderboardText.setFont(new Font("Arial", Font.PLAIN, 16));
            leaderboardText.setForeground(LIGHT_TEXT);
            leaderboardText.setBackground(new Color(40, 40, 55));
            leaderboardText.setEditable(false);
            leaderboardText.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
            
            List<PlayerProfile> sortedProfiles = new ArrayList<>(savedGames.values());
            sortedProfiles.sort((p1, p2) -> Integer.compare(p2.highScore, p1.highScore));
            
            StringBuilder sb = new StringBuilder();
            if (sortedProfiles.isEmpty()) {
                sb.append("No players yet! Start a new game to appear here.\n");
            } else {
                sb.append("TOP PREHISTORIC RUNNERS:\n\n");
                for (int i = 0; i < Math.min(sortedProfiles.size(), 10); i++) {
                    PlayerProfile profile = sortedProfiles.get(i);
                    sb.append(String.format("%d. %s - High Score: %d\n", 
                        i + 1, profile.playerName, profile.highScore));
                }
            }
            
            leaderboardText.setText(sb.toString());
            
            JScrollPane scrollPane = new JScrollPane(leaderboardText);
            scrollPane.setBorder(BorderFactory.createLineBorder(new Color(80, 80, 100), 2));
            panel.add(scrollPane, BorderLayout.CENTER);

            JPanel backPanel = new JPanel();
            backPanel.setBackground(DARK_BG);
            backPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 0, 0));
            JButton backButton = createActionButton("BACK TO TITLE");
            backButton.addActionListener(e -> cardLayout.show(mainContainer, "TITLE"));
            backPanel.add(backButton);
            panel.add(backPanel, BorderLayout.SOUTH);

            return panel;
        }

        private void showStartGameScreen() {
            refreshStartGamePanel();
            cardLayout.show(mainContainer, "START_GAME");
        }

        private void showLeaderboards() {
            refreshLeaderboardsPanel();
            cardLayout.show(mainContainer, "LEADERBOARDS");
        }

        private void saveGameData() {
            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(SAVE_FILE))) {
                oos.writeObject(savedGames);
            } catch (IOException e) {
                System.err.println("Error saving game data: " + e.getMessage());
            }
        }

        @SuppressWarnings("unchecked")
        private void loadSavedGames() {
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(SAVE_FILE))) {
                savedGames = (Map<Integer, PlayerProfile>) ois.readObject();
            } catch (FileNotFoundException e) {
                savedGames = new HashMap<>();
            } catch (IOException | ClassNotFoundException e) {
                System.err.println("Error loading game data: " + e.getMessage());
                savedGames = new HashMap<>();
            }
        }

        private void initializeGame() {
            dinosaurY = getGroundLevel();
            dinosaurVelocity = 0;
            gameFinished = false; 
            isJumping = false;
            gameRunning = false;
            score = 0;
            highScore = 0;
            gameSpeed = 8;
            obstacles.clear();
            clouds.clear();
            terrainSegments.clear();
            meteors.clear(); 
            isMeteorPhase = false; 
            canDoubleJump = false; 
            hasDoubleJumped = false; 
            
            generateTerrain();
            
            for (int i = 0; i < 5; i++) {
                clouds.add(new Cloud(random.nextInt(getWidth()), 30 + random.nextInt(100), 1 + random.nextInt(2), 30 + random.nextInt(40)));
            }
            
            scoreLabel.setText("Score: " + score);
            highScoreLabel.setText("High Score: " + highScore);
        }

        private void generateTerrain() {
        terrainSegments.clear();
        int currentX = 0;
        int segmentWidth = 100;
        
        while (currentX < getWidth() + segmentWidth) {
            int height = 20 + random.nextInt(30);
            Color color;
            if (isMeteorPhase) {
                color = new Color(100, 40, 0);
            } else if (isNightMode) {
                color = new Color(80, 60, 40);
            } else {
                color = new Color(139, 69, 19);
            }
            boolean hasGrass = random.nextBoolean();
            
            terrainSegments.add(new TerrainSegment(currentX, height, segmentWidth, color, hasGrass));
            currentX += segmentWidth;
        }
    }

        private void startGame() {
            if (currentPlayer == null) {
                JOptionPane.showMessageDialog(this, 
                    "Please select a save slot first!", "No Player Selected", 
                    JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            initializeGame();
            gameRunning = true;
            gameTimer.start();
            startButton.setEnabled(false);
            playRunSound();
            requestFocusInWindow();
            meteors.clear();
            isMeteorPhase = false;
        }

        private void loadAnimatedGIFs() {
            try {
                dinoRunFrames = loadGifFrames("Assets/Sprites/Dino/dinosaurrun.gif");
                if (dinoRunFrames == null || dinoRunFrames.isEmpty()) {
                    createFallbackRunAnimation();
                }
                
                dinoDuckFrames = loadGifFrames("Assets/Sprites/Dino/crouch.gif");
                if (dinoDuckFrames == null || dinoDuckFrames.isEmpty()) {
                    createFallbackDuckAnimation();
                }
                
                dinoJump = loadImage("Assets/Sprites/Dino/dinosaurjump.png");
                titleSprite = loadImage("Assets/Sprites/UI/Game title.png");
                
                rockSprite = loadImage("Assets/Sprites/obs/Rocks.png");
                treeSprite = loadImage("Assets/Sprites/obs/tree.png");
                pterodactylSprite = loadImage("Assets/Sprites/obs/Pterodactyl.GIF");
                
                createFallbackObstacleSprites();
                endingSprite = loadImage("Assets/Sprites/UI/Ending msg.png");
                
                    if (endingSprite == null) {
                    endingSprite = createFallbackEndingSprite();
                }
            } catch (Exception e) {
                e.printStackTrace();
                createFallbackSprites();
            }
        }

        private BufferedImage createFallbackEndingSprite() {
        BufferedImage img = new BufferedImage(600, 400, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = img.createGraphics();
        
        // Background gradient
        GradientPaint gradient = new GradientPaint(
            0, 0, new Color(70, 130, 180),
            600, 400, new Color(30, 60, 90)
        );
        g2d.setPaint(gradient);
        g2d.fillRect(0, 0, 600, 400);
        
        // Text
        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("Arial", Font.BOLD, 36));
        FontMetrics fm = g2d.getFontMetrics();
        String text = "CONGRATULATIONS!";
        int textWidth = fm.stringWidth(text);
        g2d.drawString(text, (600 - textWidth) / 2, 150);
        
        g2d.setFont(new Font("Arial", Font.PLAIN, 24));
        String subText = "You've Completed Prehistoric Rush!";
        int subTextWidth = fm.stringWidth(subText);
        g2d.drawString(subText, (600 - subTextWidth) / 2, 200);
        
        // Dinosaur silhouette
        g2d.setColor(new Color(255, 215, 0));
        g2d.fillOval(250, 250, 100, 60); // Body
        g2d.fillRect(230, 240, 20, 40);  // Neck
        g2d.fillOval(220, 220, 30, 30);  // Head
        g2d.fillRect(260, 300, 15, 40);  // Leg 1
        g2d.fillRect(285, 300, 15, 40);  // Leg 2
        
        g2d.dispose();
        return img;
    }

        private void createFallbackObstacleSprites() {
            if (rockSprite == null) rockSprite = createColoredImage(25, 15, new Color(120, 120, 120));
            if (treeSprite == null) treeSprite = createColoredImage(20, 45, new Color(100, 80, 60));
            if (pterodactylSprite == null) pterodactylSprite = createColoredImage(35, 20, new Color(150, 100, 200));
        }

        private List<BufferedImage> loadGifFrames(String gifPath) {
            List<BufferedImage> frames = new ArrayList<>();
            try {
                File gifFile = new File(gifPath);
                if (!gifFile.exists()) {
                    return frames;
                }
                
                ImageInputStream input = ImageIO.createImageInputStream(gifFile);
                Iterator<ImageReader> readers = ImageIO.getImageReadersByFormatName("gif");
                
                if (!readers.hasNext()) {
                    return frames;
                }
                
                ImageReader reader = readers.next();
                reader.setInput(input);
                
                int numFrames = reader.getNumImages(true);
                
                for (int i = 0; i < numFrames; i++) {
                    BufferedImage frame = reader.read(i);
                    if (frame != null) {
                        frames.add(frame);
                    }
                }
                
                reader.dispose();
                input.close();
                
            } catch (Exception e) {
                System.err.println("Error loading GIF: " + gifPath);
            }
            return frames;
        }

        private void createFallbackRunAnimation() {
            dinoRunFrames = new ArrayList<>();
            dinoRunFrames.add(createColoredImage(40, 50, Color.GREEN));
            dinoRunFrames.add(createColoredImage(40, 50, new Color(0, 200, 0)));
            dinoRunFrames.add(createColoredImage(40, 50, Color.GREEN));
            dinoRunFrames.add(createColoredImage(40, 50, new Color(0, 150, 0)));
        }

        private void createFallbackDuckAnimation() {
            dinoDuckFrames = new ArrayList<>();
            dinoDuckFrames.add(createColoredImage(50, 25, Color.GREEN));
            dinoDuckFrames.add(createColoredImage(50, 25, new Color(0, 200, 0)));
        }

        private void createFallbackSprites() {
            if (dinoRunFrames == null || dinoRunFrames.isEmpty()) {
                createFallbackRunAnimation();
            }
            if (dinoDuckFrames == null || dinoDuckFrames.isEmpty()) {
                createFallbackDuckAnimation();
            }
            if (dinoJump == null) {
                dinoJump = createColoredImage(30, 50, Color.GREEN);
            }
            createFallbackObstacleSprites();
        }

        private BufferedImage createColoredImage(int width, int height, Color color) {
            BufferedImage img = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2d = img.createGraphics();
            g2d.setColor(color);
            g2d.fillRect(0, 0, width, height);
            g2d.dispose();
            return img;
        }

        private void loadSounds() {
            try {
                jumpSound = loadSound("Assets/Sprites/Dino/Jump Updated 1.wav");
                runSound = loadSound("Assets/Sprites/Dino/run-walk.wav");
                crashSound = loadSound("Assets/Sprites/Dino/Destroyed obliterated.wav");
                soundsLoaded = true;
            } catch (Exception e) {
                System.err.println("Error loading sounds: " + e.getMessage());
                soundsLoaded = false;
            }
        }

        private Clip loadSound(String soundPath) {
            try {
                File soundFile = new File(soundPath);
                if (!soundFile.exists()) {
                    return null;
                }
                
                AudioInputStream audioStream = AudioSystem.getAudioInputStream(soundFile);
                Clip clip = AudioSystem.getClip();
                clip.open(audioStream);
                return clip;
            } catch (Exception e) {
                System.err.println("Error loading sound: " + soundPath);
                return null;
            }
        }

        private void playJumpSound() {
            if (soundsLoaded && jumpSound != null) {
                setVolume(jumpSound, volume);
                jumpSound.setFramePosition(0);
                jumpSound.start();
            }
        }

            private void setVolume(Clip clip, float volume) {
            if (clip != null) {
                FloatControl gainControl = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
                float dB = (float) (Math.log(volume) / Math.log(10.0) * 20.0);
                gainControl.setValue(dB);
            }
        }

        private void playRunSound() {
            if (soundsLoaded && runSound != null && !runSound.isRunning()) {
                runSound.loop(Clip.LOOP_CONTINUOUSLY);
            }
        }

        private void stopRunSound() {
            if (soundsLoaded && runSound != null && runSound.isRunning()) {
                runSound.stop();
            }
        }

        private void playCrashSound() {
            if (soundsLoaded && crashSound != null) {
                crashSound.setFramePosition(0);
                crashSound.start();
            }
        }

        private BufferedImage loadImage(String path) {
            try {
                File file = new File(path);
                if (!file.exists()) {
                    return null;
                }
                return ImageIO.read(file);
            } catch (Exception e) {
                System.err.println("Error loading image: " + path);
                return null;
            }
        }

        private void drawGame(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        if (isMeteorPhase) {
            g2d.setColor(new Color(255, 140, 0));
            g2d.fillRect(0, 0, getWidth(), getHeight());

            GradientPaint gradient = new GradientPaint(
                0, getHeight() / 2, new Color(200, 80, 0),
                0, getHeight(), new Color(150, 50, 0)
            );
            g2d.setPaint(gradient);
            g2d.fillRect(0, getHeight() / 2, getWidth(), getHeight() / 2);
            
        } else if (isNightMode) {
            g2d.setColor(new Color(10, 10, 40));
        } else {
            g2d.setColor(new Color(135, 206, 235));
        }
        g2d.fillRect(0, 0, getWidth(), getHeight());

        if (!isMeteorPhase && isNightMode) {
            g2d.setColor(Color.WHITE);
            for (int i = 0; i < 50; i++) {
                int x = random.nextInt(getWidth());
                int y = random.nextInt(getHeight() / 2);
                g2d.fillOval(x, y, 1, 1);
            }
        }

        g2d.setColor(isNightMode ? new Color(100, 100, 120) : Color.WHITE);
        for (Cloud cloud : clouds) {
            g2d.fillOval(cloud.x, cloud.y, cloud.size, cloud.size / 2);
        }

        for (Meteor meteor : meteors) {
            meteor.draw(g2d);
        }
        
        int groundLevel = getGroundLevel();
        for (TerrainSegment segment : terrainSegments) {
            segment.draw(g2d, groundLevel);
        }
        
        for (Obstacle obstacle : obstacles) {
            BufferedImage sprite = obstacle.getSprite();
            if (sprite != null) {
                g2d.drawImage(sprite, obstacle.x, obstacle.y, obstacle.width, obstacle.height, null);
            }
        }
        
        drawDinosaur(g2d);
        
        if (currentPlayer != null) {
            g2d.setColor(isNightMode ? LIGHT_TEXT : Color.BLACK);
            g2d.setFont(new Font("Arial", Font.BOLD, 12));
            g2d.drawString("Player: " + currentPlayer.playerName, 10, 20);
        }
    }

        private void drawDinosaur(Graphics2D g2d) {
        if (isJumping) {
            g2d.drawImage(dinoJump, 50, dinosaurY - 100, 150, 125, null);
        } else if (isDucking) {
            BufferedImage duckFrame = dinoDuckFrames.get(currentDuckFrame);
            g2d.drawImage(duckFrame, 50, dinosaurY - 100, 150, 125, null);
        } else {
            BufferedImage runFrame = dinoRunFrames.get(currentRunFrame);
            g2d.drawImage(runFrame, 50, dinosaurY - 100, 150, 125, null);
        }
    }

        @Override
        public void actionPerformed(ActionEvent e) {
            if (gameRunning) {
                updateGame();
                repaint();
            }
        }

        private void updateGame() {
            score++;
            scoreLabel.setText("Score: " + score);

            if (score % 100 == 0) {
                scoreLabel.setForeground(ACCENT_COLOR);
                new Timer(500, e -> scoreLabel.setForeground(LIGHT_TEXT)).start();
            }
            
            if (score > highScore) {
                highScore = score;
                highScoreLabel.setText("High Score: " + highScore);
            }
            
            if (score % 200 == 0) {
                gameSpeed = Math.min(gameSpeed + 1, 20);
            }
            
            if (score % 200 == 0) {
                spawnChance = Math.min(spawnChance + 1, 12);
            }
            
            if (score % 1000 == 0) {
                isNightMode = !isNightMode;
                generateTerrain();
            }

            if (score >= 2000 && score < 4000) {
                if (!isMeteorPhase) {
                    isMeteorPhase = true;
                    meteors.clear(); 
                }
                
                if (random.nextInt(100) < 3) { 
                    meteors.add(new Meteor());
                }
            } else {
                if (isMeteorPhase) {
                    isMeteorPhase = false;
                    meteors.clear();
                }
            }
            for (int i = meteors.size() - 1; i >= 0; i--) {
                Meteor meteor = meteors.get(i);
                meteor.move();
                if (meteor.isOffScreen()) {
                    meteors.remove(i);
                }
            }
            
            if (isJumping) {
                dinosaurY -= dinosaurVelocity;
                dinosaurVelocity -= GRAVITY;
                
                if (dinosaurY >= getGroundLevel()) {
                    dinosaurY = getGroundLevel();
                    isJumping = false;
                    dinosaurVelocity = 0;
                    canDoubleJump = false;
                    hasDoubleJumped = false; 
                    playRunSound();
                }
            }
            
            animationCounter++;
            if (animationCounter >= ANIMATION_DELAY) {
                animationCounter = 0;
                if (!isJumping) {
                    if (isDucking) {
                        currentDuckFrame = (currentDuckFrame + 1) % dinoDuckFrames.size();
                    } else {
                        currentRunFrame = (currentRunFrame + 1) % dinoRunFrames.size();
                    }
                }
            }
            
            for (Cloud cloud : clouds) {
                cloud.move();
            }
            
            for (int i = terrainSegments.size() - 1; i >= 0; i--) {
                TerrainSegment segment = terrainSegments.get(i);
                segment.move(gameSpeed / 2);
                
                if (segment.x + segment.width < 0) {
                    terrainSegments.remove(i);
                    int lastX = terrainSegments.isEmpty() ? getWidth() : terrainSegments.get(terrainSegments.size() - 1).x + segment.width;
                    int height = 20 + random.nextInt(30);
                    Color color = isNightMode ? new Color(80, 60, 40) : new Color(139, 69, 19);
                    boolean hasGrass = random.nextBoolean();
                    terrainSegments.add(new TerrainSegment(lastX, height, segment.width, color, hasGrass));
                }
            }
            
            for (int i = obstacles.size() - 1; i >= 0; i--) {
                Obstacle obstacle = obstacles.get(i);
                obstacle.move(gameSpeed);
                
                Rectangle dinoRect = new Rectangle(50, dinosaurY - (isDucking ? 25 : 50), 
                                                isDucking ? 50 : 40, 
                                                isDucking ? 25 : 50);
                
                if (dinoRect.intersects(obstacle.getBounds())) {
                    gameOver();
                    return;
                }
                
                if (obstacle.x + obstacle.width < 0) {
                    obstacles.remove(i);
                }
            }
            
            obstacleSpawnCounter++;
            
            if (obstacleSpawnCounter >= 10) {
                obstacleSpawnCounter = 0;
                
                boolean canSpawnObstacle = obstacles.isEmpty() || 
                    obstacles.get(obstacles.size() - 1).x < getWidth() - MIN_OBSTACLE_DISTANCE;
                
                if (canSpawnObstacle && random.nextInt(100) < spawnChance) {
                    int obstacleType;
                    
                    if (score < 300) {
                        obstacleType = random.nextInt(100) < 70 ? 0 : 1;
                    } else if (score < 800) {
                        int rand = random.nextInt(100);
                        if (rand < 50) obstacleType = 0;
                        else if (rand < 85) obstacleType = 1;
                        else obstacleType = 2;
                    } else {
                        int rand = random.nextInt(100);
                        if (rand < 40) obstacleType = 0;
                        else if (rand < 75) obstacleType = 1;
                        else obstacleType = 2;
                    }
                    
                    obstacles.add(new Obstacle(obstacleType));
                }
            }
            

            if (score >= 5000 && gameRunning) {
                gameRunning = false;
                showFinishedUI();
            }

            if (score >= 5000 && !gameFinished) {
                gameFinished = true;
                showFinishedUI();
            }
        }

        
        private void gameOver() {
            playCrashSound();
            stopRunSound();
            gameRunning = false;
            gameTimer.stop();
            
            if (currentPlayer != null) {
                currentPlayer.updateScore(score);
                saveGameData();
            }
            
            JPanel gameOverPanel = new JPanel(new BorderLayout());
            gameOverPanel.setBackground(DARK_BG);
            gameOverPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
            
            JLabel titleLabel = new JLabel("GAME OVER", JLabel.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 32));
            titleLabel.setForeground(new Color(220, 80, 80));
            
            JLabel scoreLabel = new JLabel("Score: " + score, JLabel.CENTER);
            scoreLabel.setFont(new Font("Arial", Font.BOLD, 20));
            scoreLabel.setForeground(LIGHT_TEXT);
            
            JLabel highScoreLabel = new JLabel("High Score: " + highScore, JLabel.CENTER);
            highScoreLabel.setFont(new Font("Arial", Font.PLAIN, 16));
            highScoreLabel.setForeground(ACCENT_COLOR);
            
            JPanel textPanel = new JPanel(new GridLayout(3, 1, 10, 10));
            textPanel.setBackground(DARK_BG);
            textPanel.add(titleLabel);
            textPanel.add(scoreLabel);
            textPanel.add(highScoreLabel);
            
            JPanel buttonPanel = new JPanel(new FlowLayout());
            buttonPanel.setBackground(DARK_BG);
            buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 0, 0));
            
            JButton playAgainButton = createActionButton("PLAY AGAIN");
            JButton titleButton = createActionButton("TITLE SCREEN");
            
            playAgainButton.addActionListener(e -> {
                Window window = SwingUtilities.getWindowAncestor(gameOverPanel);
                if (window != null) {
                    window.dispose();
                }
                startGame();
            });
            
            titleButton.addActionListener(e -> {
                Window window = SwingUtilities.getWindowAncestor(gameOverPanel);
                if (window != null) {
                    window.dispose();
                }
                cardLayout.show(mainContainer, "TITLE");
            });
            
            buttonPanel.add(playAgainButton);
            buttonPanel.add(titleButton);
            
            gameOverPanel.add(textPanel, BorderLayout.CENTER);
            gameOverPanel.add(buttonPanel, BorderLayout.SOUTH);
            
            JOptionPane.showMessageDialog(this, gameOverPanel, "Game Over", 
                JOptionPane.PLAIN_MESSAGE);
            
            if (score > highScore) {
                highScore = score;
                this.highScoreLabel.setText("High Score: " + highScore);
            }
            startButton.setEnabled(true);
            startButton.setText("Restart Game");

            screenShakeOffset = 10;
            new Timer(50, e -> {
                screenShakeOffset -= 2;
                if (screenShakeOffset <= 0) {
                    screenShakeOffset = 0;
                    ((Timer)e.getSource()).stop();
                }
                repaint();
            }).start();
        }

        private void showLoadingScreen() {
            JPanel loadingPanel = new JPanel(new BorderLayout());
            loadingPanel.setBackground(DARK_BG);
            JLabel loadingLabel = new JLabel("Loading Prehistoric Rush...", JLabel.CENTER);
            loadingLabel.setForeground(LIGHT_TEXT);
            loadingLabel.setFont(new Font("Arial", Font.BOLD, 18));
            loadingPanel.add(loadingLabel, BorderLayout.CENTER);
            mainContainer.add(loadingPanel, "LOADING");
            cardLayout.show(mainContainer, "LOADING");
        }

        private void showFinishedUI() {
        if (currentPlayer != null) {
            currentPlayer.updateScore(score);
            saveGameData();
        }
        Component[] components = mainContainer.getComponents();
        for (Component comp : components) {
            if (comp == finishedPanel) {
                mainContainer.remove(comp);
                break;
            }
        }

        
        
        finishedPanel = new JPanel(new BorderLayout());
        finishedPanel.setBackground(DARK_BG);
        finishedPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Create main content panel
        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBackground(DARK_BG);
        
        // Add ending sprite
        if (endingSprite != null) {
            JLabel endingImageLabel = new JLabel(new ImageIcon(endingSprite));
            endingImageLabel.setHorizontalAlignment(JLabel.CENTER);
            contentPanel.add(endingImageLabel, BorderLayout.CENTER);
        }
        
        // Text panel
        JPanel textPanel = new JPanel(new GridLayout(3, 1, 10, 10));
        textPanel.setBackground(DARK_BG);
        textPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        
        JLabel finishedLabel = new JLabel("CONGRATULATIONS!", JLabel.CENTER);
        finishedLabel.setFont(new Font("Arial", Font.BOLD, 32));
        finishedLabel.setForeground(ACCENT_COLOR);
        
        JLabel subLabel = new JLabel("You've Completed Prehistoric Rush!", JLabel.CENTER);
        subLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        subLabel.setForeground(LIGHT_TEXT);
        
        JLabel scoreLabel = new JLabel("Final Score: " + score, JLabel.CENTER);
        scoreLabel.setFont(new Font("Arial", Font.BOLD, 24));
        scoreLabel.setForeground(new Color(100, 200, 100));
        
        textPanel.add(finishedLabel);
        textPanel.add(subLabel);
        textPanel.add(scoreLabel);
        

        contentPanel.add(textPanel, BorderLayout.SOUTH);
        

        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setBackground(DARK_BG);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 0, 0));
        
        JButton playAgainButton = createMinecraftStyleButton("PLAY AGAIN", PRIMARY_COLOR);
        JButton titleButton = createMinecraftStyleButton("TITLE SCREEN", new Color(70, 130, 180));
        
        playAgainButton.addActionListener(e -> {
            mainContainer.remove(finishedPanel);
            cardLayout.show(mainContainer, "GAME");
            startGame();
        });
        
        titleButton.addActionListener(e -> {
            mainContainer.remove(finishedPanel);
            cardLayout.show(mainContainer, "TITLE");
        });
        
        buttonPanel.add(playAgainButton);
        buttonPanel.add(titleButton);
        
        finishedPanel.add(contentPanel, BorderLayout.CENTER);
        finishedPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        mainContainer.add(finishedPanel, "FINISHED");
        cardLayout.show(mainContainer, "FINISHED");
    }

        @Override
        public void keyPressed(KeyEvent e) {
            if (!gameRunning) return;
            
            int keyCode = e.getKeyCode();
            if ((keyCode == KeyEvent.VK_SPACE || keyCode == KeyEvent.VK_UP)) {
                if (!isJumping) {
                    // First jump
                    isJumping = true;
                    dinosaurVelocity = JUMP_STRENGTH;
                    canDoubleJump = true;
                    hasDoubleJumped = false;
                    stopRunSound();
                    playJumpSound();
                } else if (canDoubleJump && !hasDoubleJumped) {
                    // Double jump
                    dinosaurVelocity = DOUBLE_JUMP_STRENGTH;
                    canDoubleJump = false;
                    hasDoubleJumped = true;
                    playJumpSound(); // Play jump sound again
                }
            } else if (keyCode == KeyEvent.VK_DOWN) {
                isDucking = true;
            }
        }

            private void togglePause() {
            if (!gameRunning) return;
            
            isPaused = !isPaused;
            if (isPaused) {
                gameTimer.stop();
                stopRunSound();
            } else {
                gameTimer.start();
                if (!isJumping) {
                    playRunSound();
                }
            }
            repaint();
        }

        

        @Override
        public void keyReleased(KeyEvent e) {
            if (e.getKeyCode() == KeyEvent.VK_DOWN) {
                isDucking = false;
            }
        }

        @Override
        public void keyTyped(KeyEvent e) {}

        public static void main(String[] args) {
            SwingUtilities.invokeLater(() -> {
                new DinosaurGameV3();
            });
        }
    }