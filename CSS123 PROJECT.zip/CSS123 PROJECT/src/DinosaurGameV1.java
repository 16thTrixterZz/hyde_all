import javax.swing.*;
import java.io.File;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Random;
import javax.imageio.ImageIO;

public class DinosaurGameV1 extends JFrame implements ActionListener, KeyListener {
    private CardLayout cardLayout;
    private JPanel mainContainer;
    private static final int WIDTH = 800;
    private static final int HEIGHT = 300;
    private int getGroundLevel() {
        return getHeight() - 50; 
    }
    private static final int GRAVITY = 1;
    private static final int JUMP_STRENGTH = 15;
    
    private Timer gameTimer;
    private int dinosaurY;
    private int dinosaurVelocity;
    private boolean isJumping;
    private boolean gameRunning;
    private int score;
    private int highScore;
    private int gameSpeed;
    
    private ArrayList<Obstacle> obstacles;
    private Random random;
    private BufferedImage terrainSprite;
    private int terrainOffset = 0;
    private ArrayList<Cloud> clouds;
    // ============================================
    // ASSET TEAM: SPRITE VARIABLES
    // ============================================
    private BufferedImage dinoRun1, dinoRun2, dinoJump, dinoDuck;
    private BufferedImage cactusSmall, cactusLarge, bird;
    private BufferedImage titleSprite;
    
    private int animationFrame = 0;
    private boolean isDucking = false;
    private boolean isNightMode = false;
    private boolean birdsMove = false;
    private int spawnChance = 7;
    
    private JLabel scoreLabel;
    private JLabel highScoreLabel;
    private JButton startButton;
    private JPanel finishedPanel;

    public DinosaurGameV1() {
        setTitle("Prehistoric Rush");
        setSize(WIDTH, HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(true);
        setMinimumSize(new Dimension(400, 200));
        loadSprites();


        cardLayout = new CardLayout();
        mainContainer = new JPanel(cardLayout);
        // Setup panels
        JPanel gamePanelContainer = new JPanel(new BorderLayout());
        setupUI(gamePanelContainer);
        JPanel titleScreenPanel = createTitleScreenPanel();
        mainContainer.add(titleScreenPanel, "TITLE");
        mainContainer.add(gamePanelContainer, "GAME");
        setContentPane(mainContainer);
        initializeGame();

        addKeyListener(this);
        setFocusable(true);
        gameTimer = new Timer(20, this);
        cardLayout.show(mainContainer, "TITLE");

        addComponentListener(new ComponentAdapter() {
        @Override
        public void componentResized(ComponentEvent e) {
            // Update dinosaur position when window is resized
            if (!isJumping) {
                dinosaurY = getGroundLevel();
            }
            // Update all obstacle positions
            for (Obstacle obstacle : obstacles) {
                int currentGround = getGroundLevel();
                if (obstacle.type == 0 || obstacle.type == 1) {
                    obstacle.y = currentGround - obstacle.height;
                } else if (obstacle.type == 2) {
                    int relativeHeight = obstacle.y - (getHeight() - 50);
                    obstacle.y = currentGround + relativeHeight;
                }
            }
            // Reset clouds for new window size
            for (Cloud cloud : clouds) {
                if (cloud.x > getWidth()) {
                    cloud.x = cloud.x % getWidth();
                }
            }
            repaint();
        }
    });
        setVisible(true);
    }

    class Cloud {
    int x, y, speed, size;
    
    Cloud(int x, int y, int speed, int size) {
        this.x = x;
        this.y = y;
        this.speed = speed;
        this.size = size;
    }
    
    void move() {
        x -= speed;
        if (x + size < 0) {
            x = getWidth();
            y = 30 + random.nextInt(100);
        }
    }
}


    //ONLY IF SPIRTES ARE NOT LOADING

/* 
    private void debugFilePaths() {
    String[] pathsToCheck = {
        "assets/Sprites/UI/Game title.png",
        "Assets/Sprites/UI/Game title.png", 
        "Sprites/UI/Game title.png",
        "Game title.png"
    };
    
    System.out.println("=== FILE PATH DEBUG ===");
    for (String path : pathsToCheck) {
        File file = new File(path);
        System.out.println("Path: " + path + " | Exists: " + file.exists() + " | Absolute: " + file.getAbsolutePath());
    }
    System.out.println("Current working directory: " + System.getProperty("user.dir"));
    System.out.println("========================");
}
*/

    private JPanel createTitleScreenPanel() {
    JPanel panel = new JPanel(new BorderLayout());
    panel.setBackground(Color.WHITE);

    // Use the pre-loaded title sprite
    if (titleSprite != null) {
        ImageIcon titleIcon = new ImageIcon(titleSprite);
        JLabel titleImageLabel = new JLabel(titleIcon);
        titleImageLabel.setHorizontalAlignment(JLabel.CENTER);
        panel.add(titleImageLabel, BorderLayout.NORTH);
    } else {
        // Fallback if sprite loading failed
        JLabel label = new JLabel("DINO GAME", JLabel.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 48));
        label.setForeground(new Color(60, 60, 60));
        panel.add(label, BorderLayout.NORTH);
        System.err.println("Title sprite not loaded - using fallback text");
    }

    JButton playButton = new JButton("Start Game");
    playButton.setFont(new Font("Arial", Font.BOLD, 24));
    playButton.addActionListener(e -> {
        cardLayout.show(mainContainer, "GAME");
        startGame();
    });
    
    JPanel buttonPanel = new JPanel();
    buttonPanel.setBackground(Color.WHITE);
    buttonPanel.add(playButton);
    panel.add(buttonPanel, BorderLayout.SOUTH);
    
    return panel;
}

    private void loadSprites() {
    try {
        dinoRun1 = loadImage("assets/dino_run1.png");
        dinoRun2 = loadImage("assets/dino_run2.png");
        dinoJump = loadImage("assets/dino_jump.png");
        dinoDuck = loadImage("assets/dino_duck.png");
        cactusSmall = loadImage("assets/cactus_small.png");
        cactusLarge = loadImage("assets/cactus_large.png");
        bird = loadImage("assets/bird.png");
        titleSprite = loadImage("assets/Sprites/UI/Game title.png");
    } catch (Exception e) {
        System.err.println("Error loading sprites: " + e.getMessage());
    }
    terrainSprite = loadImage("assets/terrain.png");
    if (terrainSprite == null) {
        terrainSprite = createTerrainSprite();
    }
    
    System.out.println("Sprites loaded successfully!");
    }
 
    private BufferedImage createTerrainSprite() {
        int terrainWidth = 800;
        int terrainHeight = 100;
        BufferedImage terrain = new BufferedImage(terrainWidth, terrainHeight, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = terrain.createGraphics();
        
        // Base ground color
        g2d.setColor(new Color(83, 83, 83));
        g2d.fillRect(0, 60, terrainWidth, 40);
        
        // Top layer with variation
        g2d.setColor(new Color(105, 105, 105));
        g2d.fillRect(0, 60, terrainWidth, 10);
        
        // Add ground details (pebbles, cracks, etc.)
        g2d.setColor(new Color(70, 70, 70));
        Random rand = new Random();
        for (int i = 0; i < 50; i++) {
            int x = rand.nextInt(terrainWidth);
            int y = 65 + rand.nextInt(15);
            int size = 1 + rand.nextInt(3);
            g2d.fillOval(x, y, size, size);
        }
        
        // Add some grass/blades
        g2d.setColor(new Color(100, 130, 80));
        for (int i = 0; i < 30; i++) {
            int x = rand.nextInt(terrainWidth);
            int height = 2 + rand.nextInt(8);
            g2d.drawLine(x, 60, x, 60 - height);
        }
        
        g2d.dispose();
        return terrain;
    }

    private BufferedImage loadImage(String path) {
    try {
        File file = new File(path);
        if (file.exists()) {
            BufferedImage img = ImageIO.read(file);
            if (img != null) {
                System.out.println("Successfully loaded: " + path);
                return img;
            }
        }
        // Try alternative paths
        String[] alternativePaths = {
            path,
            "Assets/" + path,
            "assets/" + path,
            path.toLowerCase(),
            "resources/" + path
        };
        
        for (String altPath : alternativePaths) {
            file = new File(altPath);
            if (file.exists()) {
                BufferedImage img = ImageIO.read(file);
                if (img != null) {
                    System.out.println("Successfully loaded from alternative path: " + altPath);
                    return img;
                }
            }
        }
        System.err.println("Could not load image: " + path);
    } catch (Exception e) {
        System.err.println("Error loading image " + path + ": " + e.getMessage());
    }
    return null;
}
    
private class GamePanel extends JPanel {
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        int currentWidth = getWidth();
        int currentHeight = getHeight();
        int dynamicGround = getGroundLevel();
        
        // Draw sky background
        if (isNightMode) {
            g.setColor(new Color(20, 20, 40)); // Night sky
        } else {
            // Day sky with gradient
            Graphics2D g2d = (Graphics2D) g;
            GradientPaint skyGradient = new GradientPaint(
                0, 0, new Color(135, 206, 235), // Light blue at top
                0, currentHeight, new Color(255, 255, 255) // White at bottom
            );
            g2d.setPaint(skyGradient);
            g2d.fillRect(0, 0, currentWidth, dynamicGround);
        }
        
        // Draw clouds
        g.setColor(new Color(255, 255, 255, 200));
        for (Cloud cloud : clouds) {
            g.fillOval(cloud.x, cloud.y, cloud.size, cloud.size / 2);
            g.fillOval(cloud.x + cloud.size/3, cloud.y - cloud.size/4, cloud.size, cloud.size / 2);
            g.fillOval(cloud.x + cloud.size/2, cloud.y, cloud.size, cloud.size / 2);
        }
        
        // Draw scrolling terrain
        if (terrainSprite != null) {
            // Draw multiple terrain sprites to cover the width and enable scrolling
            int terrainWidth = terrainSprite.getWidth();
            for (int x = -terrainOffset; x < currentWidth; x += terrainWidth) {
                g.drawImage(terrainSprite, x, dynamicGround - terrainSprite.getHeight(), null);
            }
        } else {
            // Fallback: draw simple terrain
            g.setColor(new Color(83, 83, 83));
            g.fillRect(0, dynamicGround, currentWidth, currentHeight - dynamicGround);
            
            // Add terrain texture
            g.setColor(new Color(105, 105, 105));
            g.fillRect(0, dynamicGround, currentWidth, 10);
        }
        
        // Draw dinosaur
        if (isJumping) {
            if (dinoJump != null) {
                g.drawImage(dinoJump, 50, dinosaurY - 43, null);
            } else {
                g.setColor(Color.GREEN);
                g.fillRect(50, dinosaurY - 30, 20, 30);
            }
        } else if (isDucking) {
            if (dinoDuck != null) {
                g.drawImage(dinoDuck, 50, dinosaurY - 25, null);
            } else {
                g.setColor(Color.GREEN);
                g.fillRect(50, dinosaurY - 20, 30, 20);
            }
        } else {
            if (dinoRun1 != null && dinoRun2 != null) {
                BufferedImage dino = (animationFrame % 2 == 0) ? dinoRun1 : dinoRun2;
                g.drawImage(dino, 50, dinosaurY - 43, null);
            } else {
                g.setColor(Color.GREEN);
                g.fillRect(50, dinosaurY - 30, 20, 30);
            }
        }
        
        // Draw obstacles
        for (Obstacle obstacle : obstacles) {
            if (obstacle.type == 0) {
                if (cactusSmall != null) {
                    g.drawImage(cactusSmall, obstacle.x, obstacle.y, null);
                } else {
                    g.setColor(Color.RED);
                    g.fillRect(obstacle.x, obstacle.y, 15, 30);
                }
            } else if (obstacle.type == 1) {
                if (cactusLarge != null) {
                    g.drawImage(cactusLarge, obstacle.x, obstacle.y, null);
                } else {
                    g.setColor(Color.YELLOW);
                    g.fillRect(obstacle.x, obstacle.y, 25, 40);
                }
            } else if (obstacle.type == 2) {
                if (bird != null) {
                    g.drawImage(bird, obstacle.x, obstacle.y, null);
                } else {
                    g.setColor(Color.BLUE);
                    g.fillRect(obstacle.x, obstacle.y, 45, 20);
                }
            }
        }
        
        // Game over screen
        if (!gameRunning && score > 0) {
            g.setColor(new Color(0, 0, 0, 150));
            g.fillRect(0, 0, currentWidth, currentHeight);
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 30));
            
            String gameOverText = "Game Over!";
            String scoreText = "Score: " + score;
            String highScoreText = "High Score: " + highScore;
            
            FontMetrics fm = g.getFontMetrics();
            
            g.drawString(gameOverText, (currentWidth - fm.stringWidth(gameOverText)) / 2, currentHeight/2 - 30);
            g.drawString(scoreText, (currentWidth - fm.stringWidth(scoreText)) / 2, currentHeight/2);
            g.drawString(highScoreText, (currentWidth - fm.stringWidth(highScoreText)) / 2, currentHeight/2 + 30);
        }
    }
}
    
    private void setupUI(JPanel mainPanel) {
        mainPanel.setBackground(Color.WHITE);
        JPanel scorePanel = new JPanel(new FlowLayout());
        scoreLabel = new JLabel("Score: 0");
        highScoreLabel = new JLabel("High Score: 0");
        startButton = new JButton("Start Game");
        startButton.addActionListener(this);
        scorePanel.add(startButton);
        scorePanel.add(scoreLabel);
        scorePanel.add(highScoreLabel);
        mainPanel.add(scorePanel, BorderLayout.NORTH);
        mainPanel.add(new GamePanel(), BorderLayout.CENTER);
    }
    
    private void initializeGame() {
        dinosaurY = getGroundLevel();
        dinosaurVelocity = 0;
        isJumping = false;
        gameRunning = false;
        score = 0;
        gameSpeed = 5;
        obstacles = new ArrayList<>();
        clouds = new ArrayList<>();
        random = new Random();
        isNightMode = false;
        birdsMove = false;
        spawnChance = 5;

        for (int i = 0; i < 5; i++) {
        clouds.add(new Cloud(
            random.nextInt(getWidth()),
            30 + random.nextInt(100),
                1 + random.nextInt(2),
            30 + random.nextInt(40)));
        }
    }
    
    class Obstacle {
    int x, y, width, height, speed, type;
    int birdDirection = 1;
    int birdMoveCounter = 0;
    
    Obstacle(int x, int type, int speed) {
        this.x = x;
        this.type = type;
        this.speed = speed;
        
        int currentGround = getGroundLevel();
        
        if (type == 0) {
            this.width = 20;
            this.height = 30;
            this.y = currentGround - height;
        } else if (type == 1) {
            this.width = 25;
            this.height = 40;
            this.y = currentGround - height;
        } else if (type == 2) {
            this.width = 30;
            this.height = 20;
            this.y = currentGround - 80 - random.nextInt(70);
        }
    }
    
    void move() { 
        x -= speed;
        
        if (type == 2 && birdsMove) {
            birdMoveCounter++;
            if (birdMoveCounter >= 3) {
                y += birdDirection * 2;
                birdMoveCounter = 0;
                
                int currentGround = getGroundLevel();
                if (y < currentGround - 150 || y > currentGround - 50) {
                    birdDirection *= -1;
                }
            }
        }
    }
    
    boolean isOffScreen() { 
        return x + width < 0; 
    }
    
    Rectangle getBounds() {
        return new Rectangle(x, y, width, height);
    }
}

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == startButton) {
            startGame();
        } else if (e.getSource() == gameTimer && gameRunning) {
            updateGame();
            repaint();
        }
    }
    
    private void startGame() {
        dinosaurY = getGroundLevel();
        dinosaurVelocity = 0;
        isJumping = false;
        gameRunning = true;
        score = 0;
        gameSpeed = 5;
        obstacles.clear();
        isNightMode = false;
        birdsMove = false;
        spawnChance = 5;
        
        scoreLabel.setText("Score: 0");
        startButton.setEnabled(false);
        gameTimer.start();
    }
    
    private void showFinishedUI() {
        finishedPanel = new JPanel(new BorderLayout());
        finishedPanel.setBackground(Color.WHITE);
        JLabel finishedLabel = new JLabel("Congratulations! You finished the game!", JLabel.CENTER);
        finishedLabel.setFont(new Font("Arial", Font.BOLD, 32));
        finishedLabel.setForeground(new Color(60, 120, 60));
        finishedPanel.add(finishedLabel, BorderLayout.CENTER);
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(Color.WHITE);
        JButton restartButton = new JButton("Restart Game");
        JButton quitButton = new JButton("Quit Game");
        JButton titleButton = new JButton("Title Screen");
        restartButton.setFont(new Font("Arial", Font.BOLD, 20));
        quitButton.setFont(new Font("Arial", Font.BOLD, 20));
        titleButton.setFont(new Font("Arial", Font.BOLD, 20));
        restartButton.addActionListener(e -> {
            mainContainer.remove(finishedPanel);
            cardLayout.show(mainContainer, "GAME");
            startGame();
        });
        quitButton.addActionListener(e -> {
            System.exit(0);
        });
        titleButton.addActionListener(e -> {
            mainContainer.remove(finishedPanel);
            cardLayout.show(mainContainer, "TITLE");
        });
        buttonPanel.add(restartButton);
        buttonPanel.add(titleButton);
        buttonPanel.add(quitButton);
        finishedPanel.add(buttonPanel, BorderLayout.SOUTH);
        mainContainer.add(finishedPanel, "FINISHED");
        cardLayout.show(mainContainer, "FINISHED");
    }
    private void updateGame() {
    animationFrame++;
    
        terrainOffset = (terrainOffset + gameSpeed) % (terrainSprite != null ? terrainSprite.getWidth() : 800);
    for (Cloud cloud : clouds) {
        cloud.move();
    }

    if (isJumping) {
        int currentGravity = isDucking ? GRAVITY * 2 : GRAVITY;
        dinosaurY -= dinosaurVelocity;
        dinosaurVelocity -= currentGravity;
        
        int currentGround = getGroundLevel();
        if (dinosaurY >= currentGround) {
            dinosaurY = currentGround;
            isJumping = false;
            dinosaurVelocity = 0;
        }
    }

    int currentWidth = getWidth();
    if (obstacles.isEmpty() || obstacles.get(obstacles.size() - 1).x < currentWidth - 250) {
        if (random.nextInt(100) < spawnChance) {
            int type = random.nextInt(3);
            obstacles.add(new Obstacle(currentWidth, type, gameSpeed));
        }
    }
        
        for (int i = obstacles.size() -1; i >= 0; i--) {
            Obstacle obstacle = obstacles.get(i);
            obstacle.move();
            
            // In the collision detection part of updateGame():
            Rectangle dinoBounds;
            if (isDucking) {
                dinoBounds = new Rectangle(50, dinosaurY - 20, 30, 20);
            } else {
                dinoBounds = new Rectangle(50, dinosaurY - 30, 20, 30);
            }
            Rectangle obstacleBounds = obstacle.getBounds();

            if (dinoBounds.intersects(obstacleBounds)) {
                gameOver();
                return;
            }
        }


        if (score % 100 == 0 && score > 0) {
            gameSpeed = 5 + (score / 200);
        }
        
        if (score >= 1000 && gameSpeed > 15) {
            gameSpeed = 15;
        }
        
        if (score >= 400) {
            isNightMode = true;
        }
        
        if (score >= 800 && !isNightMode) {
            birdsMove = true;
        }
        
        if (score >= 1600) {
            spawnChance = 5;
        }
        
        for (Obstacle obstacle : obstacles) {
            obstacle.speed = gameSpeed;
        }
        
        if (obstacles.isEmpty() || obstacles.get(obstacles.size() - 1).x < WIDTH - 250) {
            if (random.nextInt(100) < spawnChance) {
                int type = random.nextInt(3);
                obstacles.add(new Obstacle(WIDTH, type, gameSpeed));
            }
        }
        
        if (score >= 2000) {
            gameRunning = false;
            gameTimer.stop();
            showFinishedUI();
            return;
        }
    }
    
    private void gameOver() {
        gameRunning = false;
        gameTimer.stop();
        
        ArrayList<String> achievements = new ArrayList<>();
        if (score >= 500) achievements.add("🏆 Journeyman Runner!");
        if (score >= 750) achievements.add("🏆 Prehistorical Explorer!");
        if (score >= 1250) achievements.add("🏆 Safety Miler!");
        if (score >= 2000) achievements.add("🏆 Jurassic Surviver!");
        
        StringBuilder message = new StringBuilder();
        message.append("Game Over!\n");
        message.append("Final Score: ").append(score).append("\n");
        message.append("High Score: ").append(highScore).append("\n\n");
        
        if (!achievements.isEmpty()) {
            message.append("Achievements Unlocked:\n");
            for (String achievement : achievements) {
                message.append(achievement).append("\n");
            }
        }
        
        JOptionPane.showMessageDialog(this, message.toString(), "Game Over", JOptionPane.INFORMATION_MESSAGE);
        
        if (score > highScore) {
            highScore = score;
            highScoreLabel.setText("High Score: " + highScore);
        }
        startButton.setEnabled(true);
        startButton.setText("Restart Game");
    }
    
    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_SPACE || e.getKeyCode() == KeyEvent.VK_UP) {
            if (gameRunning && !isJumping && !isDucking) {
                dinosaurVelocity = JUMP_STRENGTH;
                isJumping = true;
            } else if (!gameRunning && score > 0) {
                startGame();
            }
        } else if (e.getKeyCode() == KeyEvent.VK_DOWN) {
            if (gameRunning && !isJumping) {
                isDucking = true;
            }
        }
    }
    
    @Override
    public void keyReleased(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_DOWN) {
            isDucking = false;
        }
    }
    
    @Override
    public void keyTyped(KeyEvent e) {}
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new DinosaurGameV1();
        });
    }
}